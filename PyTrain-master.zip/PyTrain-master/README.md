# PyTrain
Python self training with coding samples
