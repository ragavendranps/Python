# a = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
# for x in a:
#     print(x)

# fruits = ["apple", "banana", "kiwi"]
# for fr in fruits:
#     if fr == "kiwi":
#         print(fr + " found")
#

# for x in fruits[0]:
#     print(x)

for x in range(11):
    print(x)

