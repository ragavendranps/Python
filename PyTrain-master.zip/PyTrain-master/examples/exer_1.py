print("Enter your name")
name = input()

print("enter your age")
age = int(input())

year = str(2020 - age + 100)

print("Hi " + name + ". You will be 100 years old in the year ", year)
